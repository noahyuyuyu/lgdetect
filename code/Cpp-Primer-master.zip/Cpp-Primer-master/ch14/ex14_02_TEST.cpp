#include "ex14_02.h"

int main()
{
    Sales_data cp5;
    std::cin >> cp5;
    std::cout << cp5 << std::endl;
}
