#include "disc_quote.h"

